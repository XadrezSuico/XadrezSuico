<?php /* C:\Users\joaop\git\crxc\vendor\encore\laravel-admin\src/../resources/views/partials/js.blade.php */ ?>
<?php $__currentLoopData = $js; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script src="<?php echo e(admin_asset ("$j"), false); ?>"></script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>