<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/evento/index.blade.php */ ?>
<?php $__env->startSection('title', 'Eventos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Eventos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status'), false); ?>

        </div>
    <?php endif; ?>
    <ul class="nav nav-pills">
        <li role="presentation"><a href="<?php echo e(url("/evento/new"), false); ?>">Novo Evento</a></li>
    </ul>

    <div class="box">
        <div class="box-body">
            <table id="tabela" class="table-responsive table-condensed table-striped" style="width: 100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Período</th>
                        <th>Local</th>
                        <th>Grupo de Evento</th>
                        <th width="20%">Opções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($evento->id, false); ?></td>
                            <td><?php echo e($evento->name, false); ?></td>
                            <td><?php echo e($evento->getDataInicio(), false); ?><br/><?php echo e($evento->getDataFim(), false); ?></td>
                            <td><?php echo e($evento->cidade->name, false); ?> - <?php echo e($evento->local, false); ?></td>
                            <td><?php echo e($evento->grupo_evento->name, false); ?></td>
                            <td>
                                <a class="btn btn-default" href="<?php echo e(url("/evento/edit/".$evento->id), false); ?>" role="button">Editar</a>
                                <a class="btn btn-default" href="<?php echo e(url("/evento/".$evento->id."/torneios"), false); ?>" role="button">Torneios</a>
                                <a class="btn btn-success" href="<?php echo e(url("/evento/inscricao/".$evento->id), false); ?>" role="button">Nova Inscrição</a>
                                <a class="btn btn-success" href="<?php echo e(url("/evento/inscricao/".$evento->id."/confirmacao"), false); ?>" role="button">Confirmar Inscrição</a>
                                <?php if($evento->isDeletavel()): ?> <a class="btn btn-danger" href="<?php echo e(url("/evento/delete/".$evento->id), false); ?>" role="button">Apagar</a> <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#tabela").DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>