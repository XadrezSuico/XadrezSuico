<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/evento/torneio/inscricao/relatorio/inscritos.blade.php */ ?>
<?php $__env->startSection('title', 'Relatórios > Inscrições'); ?>
<?php $__env->startSection('title_page_1', $evento->name); ?>
<?php $__env->startSection('title_page_2', "Inscritos no Torneio '".$torneio->name."'"); ?>
<?php $__env->startSection('content'); ?>
<table>
    <thead>
        <th>#</th>
        <th>Nome Completo</th>
        <th>Rating</th>
        <th>Categoria</th>
        <th>Cidade</th>
        <th>Clube</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $inscricoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscricao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($inscricao->enxadrista_id, false); ?></td>
                <td><?php echo e($inscricao->enxadrista->name, false); ?></td>
                <td><?php echo e($inscricao->enxadrista->ratingParaEvento($evento->id), false); ?></td>
                <td><?php echo e($inscricao->categoria->name, false); ?></td>
                <td><?php echo e($inscricao->cidade->name, false); ?></td>
                <td><?php if($inscricao->clube): ?> <?php echo e($inscricao->clube->name, false); ?> <?php else: ?> Sem Clube <?php endif; ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("relatorio.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>