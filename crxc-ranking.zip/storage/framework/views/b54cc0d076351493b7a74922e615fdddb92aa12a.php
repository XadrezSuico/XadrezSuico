<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/rating/list.blade.php */ ?>
<?php $__env->startSection('title', 'Tipo de Rating #'.$tipo_rating->id." - Ratings"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Tipo de Rating #<?php echo e($tipo_rating->id, false); ?> (<?php echo e($tipo_rating->name, false); ?>) - Ratings</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status'), false); ?>

        </div>
    <?php endif; ?>
    <ul class="nav nav-pills">
        <li role="presentation"><a href="<?php echo e(url("/rating"), false); ?>">Voltar à Seleção do Tipo de Rating</a></li>
    </ul>

    <div class="box">
        <div class="box-body">
            <table id="tabela" class="table-responsive table-condensed table-striped" style="width: 100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Data de Nascimento</th>
                        <th>Rating</th>
                        <th width="20%">Opções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tipo_rating->ratings()->orderBy("enxadrista_id","ASC")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($rating->id, false); ?></td>
                            <td>#<?php echo e($rating->enxadrista->id, false); ?> - <?php echo e($rating->enxadrista->name, false); ?></td>
                            <td><?php echo e($rating->enxadrista->getBorn(), false); ?></td>
                            <td><?php echo e($rating->valor, false); ?></td>
                            <td>
                                <a class="btn btn-default" href="<?php echo e(url("/rating/".$tipo_rating->id."/view/".$rating->id), false); ?>" role="button">Visualizar</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#tabela").DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>