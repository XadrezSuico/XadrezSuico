<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/evento/torneio/inscricao/index.blade.php */ ?>
<?php $__env->startSection('title', 'Evento #'.$evento->id." - Torneio #".$torneio->id." - Inscrições"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Evento #<?php echo e($evento->id, false); ?> (<?php echo e($evento->name, false); ?>) - Torneio #<?php echo e($torneio->id, false); ?> - Inscrições</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status'), false); ?>

        </div>
    <?php endif; ?>
    <ul class="nav nav-pills">
        <li role="presentation"><a href="<?php echo e(url("/evento/".$evento->id."/torneios"), false); ?>">Voltar à Lista de Torneios</a></li>
    </ul>

    <div class="box">
        <div class="box-body">
            <table id="tabela" class="table-responsive table-condensed table-striped" style="width: 100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Rating</th>
                        <th>Categoria</th>
                        <th>Cidade</th>
                        <th>Clube</th>
                        <th width="20%">Opções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $inscricoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscricao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($inscricao->id, false); ?></td>
                            <td><?php echo e($inscricao->enxadrista->name, false); ?></td>
                            <td><?php if($inscricao->enxadrista->ratings()->where([["tipo_ratings_id","=",$evento->tipo_rating->tipo_ratings_id]])->count() > 0): ?> <?php echo e($inscricao->enxadrista->ratings()->where([["tipo_ratings_id","=",$evento->tipo_rating->tipo_ratings_id]])->first()->valor, false); ?> <?php else: ?> Não Há <?php endif; ?></td>
                            <td><?php echo e($inscricao->categoria->name, false); ?></td>
                            <td><?php echo e($inscricao->cidade->name, false); ?></td>
                            <td><?php if($inscricao->clube): ?> <?php echo e($inscricao->clube->name, false); ?> <?php else: ?> Sem Clube <?php endif; ?></td>
                            <td>
                                <a class="btn btn-default" href="<?php echo e(url("/evento/".$evento->id."/torneios/".$torneio->id."/inscricoes/edit/".$inscricao->id), false); ?>" role="button">Editar</a>
                                <?php if($inscricao->isDeletavel()): ?> <a class="btn btn-danger" href="<?php echo e(url("/evento/".$evento->id."/torneios/".$torneio->id."/inscricoes/delete/".$inscricao->id), false); ?>" role="button">Apagar</a> <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#tabela").DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>