<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/vendor/adminlte/partials/menu-item.blade.php */ ?>
<?php if(is_string($item)): ?>
    <li class="header"><?php echo e($item, false); ?></li>
<?php else: ?>
    <li class="<?php echo e($item['class'], false); ?>">
        <a href="<?php echo e($item['href'], false); ?>"
           <?php if(isset($item['target'])): ?> target="<?php echo e($item['target'], false); ?>" <?php endif; ?>
        >
            <i class="fa fa-fw fa-<?php echo e(isset($item['icon']) ? $item['icon'] : 'circle-o', false); ?> <?php echo e(isset($item['icon_color']) ? 'text-' . $item['icon_color'] : '', false); ?>"></i>
            <span><?php echo e($item['text'], false); ?></span>
            <?php if(isset($item['label'])): ?>
                <span class="pull-right-container">
                    <span class="label label-<?php echo e(isset($item['label_color']) ? $item['label_color'] : 'primary', false); ?> pull-right"><?php echo e($item['label'], false); ?></span>
                </span>
            <?php elseif(isset($item['submenu'])): ?>
                <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
                </span>
            <?php endif; ?>
        </a>
        <?php if(isset($item['submenu'])): ?>
            <ul class="<?php echo e($item['submenu_class'], false); ?>">
                <?php echo $__env->renderEach('adminlte::partials.menu-item', $item['submenu'], 'item'); ?>
            </ul>
        <?php endif; ?>
    </li>
<?php endif; ?>
