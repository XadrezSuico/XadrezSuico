<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/evento/torneio/index.blade.php */ ?>
<?php $__env->startSection('title', 'Evento #'.$evento->id." - Torneios"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Evento #<?php echo e($evento->id, false); ?> (<?php echo e($evento->name, false); ?>) - Torneios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status'), false); ?>

        </div>
    <?php endif; ?>
    <ul class="nav nav-pills">
        <li role="presentation"><a href="<?php echo e(url("/evento"), false); ?>">Voltar à Lista de Eventos</a></li>
        <li role="presentation"><a href="<?php echo e(url("/evento/".$evento->id."/torneios/new"), false); ?>">Novo Torneio</a></li>
    </ul>

    <div class="box">
        <div class="box-body">
            <table id="tabela" class="table-responsive table-condensed table-striped" style="width: 100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Categorias</th>
                        <th>Inscritos</th>
                        <th>Confirmados</th>
                        <th>Não Confirmados</th>
                        <th>Template de Torneio</th>
                        <th width="20%">Opções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $torneios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $torneio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($torneio->id, false); ?></td>
                            <td><?php echo e($torneio->name, false); ?></td>
                            <td>
                                <?php $__currentLoopData = $torneio->categorias->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($categoria->categoria->name, false); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($torneio->getCountInscritos(), false); ?></td>
                            <td><?php echo e($torneio->getCountInscritosConfirmados(), false); ?></td>
                            <td><?php echo e($torneio->getCountInscritosNaoConfirmados(), false); ?></td>
                            <td>
                                <?php if($torneio->template): ?>
                                    <?php echo e($torneio->template->name, false); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-default" href="<?php echo e(url("/evento/".$evento->id."/torneios/edit/".$torneio->id), false); ?>" role="button">Editar</a>
                                <a class="btn btn-default" href="<?php echo e(url("/evento/".$evento->id."/torneios/".$torneio->id."/inscricoes"), false); ?>" role="button">Inscrições</a>
                                <a class="btn btn-success" href="<?php echo e(url("/evento/".$evento->id."/torneios/".$torneio->id."/inscricoes/sm"), false); ?>" role="button" target="_blank">Baixar Inscrições Confirmadas</a>
                                <a class="btn btn-warning" href="<?php echo e(url("/evento/".$evento->id."/torneios/".$torneio->id."/inscricoes/sm/all"), false); ?>" role="button" target="_blank">Baixar Todas as Inscrições</a>
                                <a class="btn btn-success" href="<?php echo e(url("/evento/".$evento->id."/torneios/".$torneio->id."/inscricoes/relatorio/inscricoes"), false); ?>" role="button" target="_blank">Imprimir Inscrições</a>
                                <a class="btn btn-success" href="<?php echo e(url("/evento/".$evento->id."/torneios/".$torneio->id."/inscricoes/relatorio/inscricoes/alfabetico"), false); ?>" role="button" target="_blank">Imprimir Inscrições (Alfabético)</a>
                                <a class="btn btn-success" href="<?php echo e(url("/evento/".$evento->id."/torneios/".$torneio->id."/inscricoes/relatorio/inscricoes/alfabetico/cidade"), false); ?>" role="button" target="_blank">Imprimir Inscrições (Alfabético por Cidade/Clube)</a>
                                <?php if($torneio->isDeletavel()): ?> <a class="btn btn-danger" href="<?php echo e(url("/evento/".$evento->id."/torneios/delete/".$torneio->id), false); ?>" role="button">Apagar</a> <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#tabela").DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>