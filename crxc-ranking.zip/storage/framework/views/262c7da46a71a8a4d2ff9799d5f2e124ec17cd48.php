<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/usuario/index.blade.php */ ?>
<?php $__env->startSection('title', 'Usuários'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Usuários</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status'), false); ?>

        </div>
    <?php endif; ?>
    <ul class="nav nav-pills">
        <li role="presentation"><a href="<?php echo e(url("/usuario/new"), false); ?>">Novo Usuário</a></li>
    </ul>

    <div class="box">
        <div class="box-body">
            <table class="table-responsive table-condensed table-striped" style="width: 100%">
                <thead>
                    <tr>
                        <th width="10%">#</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th width="25%">Opções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->id, false); ?></td>
                            <td><?php echo e($user->name, false); ?></td>
                            <td><?php echo e($user->email, false); ?></td>
                            <td>
                                <a class="btn btn-default" href="<?php echo e(url("/usuario/edit/".$user->id), false); ?>" role="button">Editar</a>
                                <?php if($user->isDeletavel()): ?> <a class="btn btn-danger" href="<?php echo e(url("/usuario/delete/".$user->id), false); ?>" role="button">Apagar</a> <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>