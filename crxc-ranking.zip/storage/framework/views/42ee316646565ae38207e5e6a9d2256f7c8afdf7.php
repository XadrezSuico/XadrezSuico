<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/rating/view.blade.php */ ?>
<?php $__env->startSection('title', 'Tipo de Rating #'.$tipo_rating->id." - Rating de ".$enxadrista->name); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Tipo de Rating #<?php echo e($tipo_rating->id, false); ?> (<?php echo e($tipo_rating->name, false); ?>) - Rating de <?php echo e($enxadrista->name, false); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status'), false); ?>

        </div>
    <?php endif; ?>
    <ul class="nav nav-pills">
        <li role="presentation"><a href="<?php echo e(url("/rating/list/".$tipo_rating->id), false); ?>">Voltar à Lista de Ratings</a></li>
    </ul>

    <div class="box">
		<div class="box-header">
			<h3 class="box-title">Cadastro</h3>
			<div class="pull-right box-tools">
			</div>
		</div>
        <div class="box-body">
                <h3 style="margin: 0; padding: 0;"><strong>Nome:</strong> <?php echo e($enxadrista->name, false); ?><br/></h3>
                <strong>Data de Nascimento:</strong> <?php echo e($enxadrista->getBorn(), false); ?><br/>
                <strong>Cidade:</strong> <?php echo e($enxadrista->cidade->name, false); ?><br/>
                <?php if($enxadrista->clube): ?> <strong>Clube:</strong> <?php echo e($enxadrista->clube->name, false); ?><br/> <?php endif; ?>

                <h4><strong>Rating Atual:</strong> <?php echo e($rating->valor, false); ?></h4>
        </div>
    </div>
    <div class="box">
		<div class="box-header">
			<h3 class="box-title">Movimentações de Rating</h3>
			<div class="pull-right box-tools">
			</div>
		</div>
        <div class="box-body">
            <table id="tabela" class="table-responsive table-condensed table-striped" style="width: 100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Evento</th>
                        <th>Torneio</th>
                        <th>Inicial?</th>
                        <th>Movimentação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rating->movimentacoes()->orderBy("torneio_id","ASC")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimentacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($movimentacao->id, false); ?></td>
                            <td><?php if(!$movimentacao->is_inicial): ?> <?php echo e($movimentacao->torneio->evento->name, false); ?> <?php else: ?> - <?php endif; ?></td>
                            <td><?php if(!$movimentacao->is_inicial): ?> <?php echo e($movimentacao->torneio->name, false); ?> <?php else: ?> - <?php endif; ?></td>
                            <td><?php if($movimentacao->is_inicial): ?> Sim <?php else: ?> Não <?php endif; ?></td>
                            <td><?php echo e($movimentacao->valor, false); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#tabela").DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>