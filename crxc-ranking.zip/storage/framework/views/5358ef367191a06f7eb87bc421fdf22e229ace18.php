<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/rating/index.blade.php */ ?>
<?php $__env->startSection('title', 'Rating'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Rating</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(session('status')): ?>
		<div class="alert alert-success">
				<?php echo e(session('status'), false); ?>

		</div>
	<?php endif; ?>
    <div class="box">
        <div class="box-body">
			<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : '', false); ?>">
                <label for="tipo_ratings_id">Tipo de Rating</label>
                <select id="tipo_ratings_id" name="tipo_ratings_id" class="form-control">
                    <option value=""> -- Selecione um Tipo de Rating --</option>
                    <?php $__currentLoopData = $tipos_rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipo_rating->id, false); ?>"><?php echo e($tipo_rating->name, false); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>						
            </div>
            <button id="acessar" type="button" class="btn btn-success">Enviar</button>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token(), false); ?>">
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#tipo_ratings_id").select2();
    });
    $("#acessar").on("click",function(){
        location.href = "<?php echo e(url("/rating/list"), false); ?>/".concat($("#tipo_ratings_id").val());
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>