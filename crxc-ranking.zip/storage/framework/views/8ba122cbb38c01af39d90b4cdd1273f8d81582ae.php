<?php /* C:\Users\Usuario\git\crxc-ranking\resources\views/inscricao/encerradas.blade.php */ ?>
<?php $__env->startSection("title", "INSCRIÇÕES ANTECIPADAS FINALIZADAS!"); ?>

<?php $__env->startSection('content_header'); ?>
  <h1>INSCRIÇÕES ANTECIPADAS FINALIZADAS!</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
	<style>
		.display-none, .displayNone{
			display: none;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="modal fade modal-danger" id="alerts" tabindex="-1" role="dialog" aria-labelledby="alerts">
  <div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">INSCRIÇÕES ANTECIPADAS FINALIZADAS!</h4>
        </div>
        <div class="modal-body">
        <span id="alertsMessage">O prazo para Inscrições Antecipadas para este evento se encerrou. As mesmas podem ser feitas no local conforme regulamento.</span>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">OK</button>
			</div>
		</div>
  </div>
</div>
<div class="row">
  <!-- Left col -->
  <section class="col-lg-12 connectedSortable">
	<div class="box box-primary">
		<div class="box-header">
			<h3 class="box-title">Evento: <?php echo e($evento->name, false); ?></h3>
			<div class="pull-right box-tools">
			</div>
		</div>

		<div class="box-body">
			<strong>Categorias:</strong><br/>
			<?php $__currentLoopData = $evento->categorias->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($categoria->categoria->name, false); ?>, 
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br/>
			<strong>Cidade:</strong> <?php echo e($evento->cidade->name, false); ?><br/>
			<strong>Local:</strong> <?php echo e($evento->local, false); ?><br/>
			<strong>Data:</strong> <?php echo e($evento->getDataInicio(), false); ?><br/>
			<strong>Maiores informações em:</strong> <a href="<?php echo e($evento->link, false); ?>" target="_blank"><?php echo e($evento->link, false); ?></a><br/>
			<?php if($evento->getDataFimInscricoesOnline()): ?> <h3><strong>Inscrições antecipadas até:</strong> <?php echo e($evento->getDataFimInscricoesOnline(), false); ?>.</h3><?php endif; ?>
		</div>
	</div>
  </section>
  <!-- /.Left col -->
</div>
<!-- /.row (main row) -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<!-- Morris.js charts -->
<script type="text/javascript" src="<?php echo e(url("/js/jquery.mask.min.js"), false); ?>"></script>
<script type="text/javascript">
  $(document).ready(function(){
	$("#alerts").modal();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>