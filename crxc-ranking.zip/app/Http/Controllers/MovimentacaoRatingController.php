<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MovimentacaoRatingController extends Controller
{
    //
}
